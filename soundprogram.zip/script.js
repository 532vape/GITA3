var redx = 100;
var redy = 100;
var orangex = 200;
var orangey = 100;
var yellowx = 300;
var yellowy = 100;
var greenx = 100;
var greeny = 200;
var bluex = 200;
var bluey = 200;
var purplex = 300;
var purpley = 200;
var redw = 100;
var redh = 100;
var orangew = 100;
var orangeh = 100;
var yelloww = 100;
var yellowh = 100;
var greenw = 100;
var greenh = 100;
var bluew = 100;
var blueh = 100;
var purplew = 100;
var purpleh = 100;
let cnv;
var d;
let soundred;
let soundorange;
let soundyellow;
let soundgreen;
let soundblue;
let soundpurple;
let backcolor = 200
let circle1 = "red"
let apple = false
let orange = false
let lemon = false
let watermelon = false
let water = false
var titlebutton;
var whichcanvas = 0;
var btnx = 100;
var btny = 100;

function preload(){
  soundFormats('mp3')
  soundred = loadSound("sounds/red.mp3")
  soundorange = loadSound("sounds/orange.mp3")
  soundyellow = loadSound("sounds/yellow.mp3")
  soundgreen = loadSound("sounds/green.mp3")
  soundblue = loadSound("sounds/blue.mp3")
  soundpurple = loadSound("sounds/purple.mp3")
}
function setup() {
  createCanvas(400, 400);
}
function draw(){
  if (whichcanvas == 0){
    startscreen()
  }
  if (whichcanvas == 1){
    canvas1()
  }
}
function next(){
  whichcanvas = 1
}
function back(){
  whichcanvas = 0
  console.log("3")
}
function startscreen(){
  background(220)
  strokeWeight(3)
  textSize(100)
  text("🌈",130,200)
  textSize(25)
  textFont('impact')
  text("Colors of the Rainbow",100,250)
  titlebutton = createButton("Next");
  titlebutton.mousePressed(next);
  titlebutton.position(100, 380);

  titlebutton = createButton("Back");
  titlebutton.mousePressed(back);
  titlebutton.position(230, 380);

}
function canvas1() {
  strokeWeight(20)
  stroke('black')
  hover()
  background(backcolor);
  fill(circle1)
  ellipse(redx,redy,redw,redh)
  fill("orange")
  ellipse(orangex,orangey,orangew,orangeh)
  fill("yellow")
  ellipse(yellowx,yellowy,yelloww,yellowh)
  fill("green")
  ellipse(greenx,greeny,greenw,greenh)
  fill("blue")
  ellipse(bluex,bluey,bluew,blueh)
  fill("purple")
  ellipse(purplex,purpley,purplew,purpleh)
  if (apple == true){
  noStroke()
  translate(200,350)
  fill(204, 55, 51);
  ellipseMode(CENTER);
  ellipse(0, 0, 80, 75);
  stroke(78, 38, 0);
  strokeWeight(5);
  line(-5, -50, 0, -25);
  strokeWeight(0)
  rotate(radians(-30));
  fill(39, 166, 21);
  ellipse(7, -33, 15, 25)
  }
  if (orange == true){
    noStroke()
  translate(200,350)
  fill('darkorange');
  ellipseMode(CENTER);
  ellipse(0, 0, 80, 75);
  stroke(78, 38, 0);
  strokeWeight(5);
  line(-5, -50, 0, -25);
  strokeWeight(0)
  rotate(radians(-30));
  fill(39, 166, 21);
  ellipse(7, -33, 15, 25)
  }
  if (lemon == true){
    noStroke()
  translate(200,350)
  fill('gold');
  ellipseMode(CENTER);
  ellipse(0, 0, 80, 75);
  stroke(78, 38, 0);
  strokeWeight(5);
  line(-5, -50, 0, -25);
  strokeWeight(0)
  rotate(radians(-30));
  fill(39, 166, 21);
  ellipse(7, -33, 15, 25)
  }
  if (watermelon == true){
    fill('green')
    arc(200, 300, 400*0.75, 400*0.75, 0, PI, PIE);
  fill('red');
  arc(200, 300, 400*0.63, 400*0.63, 0, PI, PIE);
  fill('black');
  ellipse(200 + 85, 300 + 65, 25);
  ellipse(200 - 85, 300 + 65, 25);
  ellipse(200, 300 + 100, 25);
  }
  if (water == true){
    strokeWeight(5)
    stroke("white")
    fill("skyblue")
    ellipse(200,330,30,30)
    rect(200-15,330,30,55)
    line(200,330,205,310)
  }
}
  

function hover(){
  //mouseover code
  r = dist(mouseX,mouseY,redx,redy)
  o = dist(mouseX,mouseY,orangex,orangey)
  y = dist(mouseX,mouseY,yellowx,yellowy)
  g = dist(mouseX,mouseY,greenx,greeny)
  b = dist(mouseX,mouseY,bluex,bluey)
  p = dist(mouseX,mouseY,purplex,purpley)
  if (r<50){
    redw = 200
    redh = 200;
    console.log("good")
  }
  else {
    redw = 100;
    redh = 100;
  }
  if (o<50){
    orangew = 200
    orangeh = 200;
    console.log("good")
  }
  else {
    orangew = 100;
    orangeh = 100;
  }
  if (y<50){
    yelloww = 200
    yellowh = 200;
    console.log("good")
  }
  else {
    yelloww = 100;
    yellowh = 100;
  }
  if (g<50){
    greenw = 200
    greenh = 200;
    console.log("good")
  }
  else {
    greenw = 100;
    greenh = 100;
  }
  if (b<50){
    bluew = 200
    blueh = 200;
    console.log("good")
  }
  else {
    bluew = 100;
    blueh = 100;
  }
  if (p<50){
    purplew = 200
    purpleh = 200;
    console.log("good")
  }
  else {
    purplew = 100;
    purpleh = 100;
  }
}
function mouseClicked(){
  r = dist(mouseX,mouseY,redx,redy)
  o = dist(mouseX,mouseY,orangex,orangey)
  y = dist(mouseX,mouseY,yellowx,yellowy)
  g = dist(mouseX,mouseY,greenx,greeny)
  b = dist(mouseX,mouseY,bluex,bluey)
  p = dist(mouseX,mouseY,purplex,purpley)
  if (r<50){
    soundred.play();
    backcolor = "red"
    apple = true
    orange = false
    lemon = false
    watermelon = false
    water = false
  }

  if (o<50){
    soundorange.play()
    backcolor = "orange"
    apple = false
    orange = true
    lemon = false
    watermelon = false
    water = false
  }

  if (y<50){
    soundyellow.play()
    backcolor = "yellow"
    apple = false
    orange = false
    lemon = true
    watermelon = false
    water = false
  }

  if (g<50){
    soundgreen.play()
    backcolor = "green"
    apple = false
    orange = false
    lemon = false
    watermelon = true
    water = false
  }
  if (b<50){
    soundblue.play()
    backcolor = "blue"
    apple = false
    orange = false
    lemon = false
    watermelon = false
    water = true
  }
  if (p<50){
    soundpurple.play()
    backcolor = "purple"
    apple = false
    orange = false
    lemon = false
    watermelon = false
    water = false
  }
}
function drawapple(){
  noStroke()
  translate(100,100)
  fill(204, 55, 51);
  ellipseMode(CENTER);
  ellipse(0, 0, 80, 75);
  stroke(78, 38, 0);
  strokeWeight(5);
  line(-5, -50, 0, -25);
  noStroke();
  rotate(radians(-30));
  fill(39, 166, 21);
  ellipse(7, -33, 15, 25)
}