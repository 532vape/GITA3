var score = 0;


var wins = 0;
var moleX;
var moleY;
var counter = 0;

function setup() {
  createCanvas(300, 450);
  mouseClicked()
  frameRate(60)
}

function draw() {
  background("orange")














counter+=1
  strokeWeight(1)
  var possibleX = [50, 250, 150];
  var possibleY = [50, 250, 150];
  if (counter % 50 == 0){
  moleX = random(possibleX);
  moleY = random(possibleY);
  }

  fill("black")
  ellipse(50, 50, 80, 80)
  ellipse(50, 150, 80, 80)
  ellipse(50, 250, 80, 80)

  ellipse(150, 50, 80, 80)
  ellipse(150, 150, 80, 80)
  ellipse(150, 250, 80, 80)

  ellipse(250, 50, 80, 80)
  ellipse(250, 150, 80, 80)
  ellipse(250, 250, 80, 80)


  fill("#FF0000")
  fill("black")
  textSize(20)




  //replace plain circles with pumpkins
  //halloween theme
  strokeWeight(10)
  stroke("green")
  line(moleX, 
       moleY - 50 * .5,
       moleX - 50 * .25, 
       moleY - 70 * .75);
  strokeWeight(3)
  stroke("black")
  fill("orange")
  ellipse(moleX, moleY, 70, 50);
  ellipse(moleX, moleY, 70 * .75, 50);
  ellipse(moleX, moleY, 70 * .5, 50);
  ellipse(moleX, moleY, 70 * .25, 50);
  
  
  
  
  //replace plain circles with pumpkins
  //halloween theme
  strokeWeight(10)
  stroke("green")
  line(150, 
       400 - 90 * .5,
       150 - 90 * .25, 
       400 - 120 * .75);
  strokeWeight(3)
  stroke("black")
  fill(252, 128, 3)
  ellipse(150, 400, 120, 90);
  ellipse(150, 400, 120 * .75, 90);
  ellipse(150, 400, 120 * .5, 90);
  ellipse(150, 400, 120 * .25, 90);

  fill("yellow")
  triangle(
    120, 375,
    95, 400,
    145, 400);

  triangle(
    180, 375,
    155, 400,
    205, 400);
  
   arc(
    150, 415,
    80, 40,
    radians(0), radians(180),
    CHORD);
  
  fill("red")
  text("score:", 115, 400)
  text(score, 175, 400)

}

 /*function mousePressed(){
  if (mouseIsPressed) {
  fill("pink");
  ellipse(moleX, moleY, 40, 40);
  }else{
   score+=1
  }
 }*/




function mouseClicked() {
 var distance = int(dist(mouseX, mouseY, moleX, moleY));

  if (distance <= 50) {
    //console.log("mole clicked");
    score+=1;
    //console.log(score)

  }

}