let astronauts = []
let asteroids = []
let ships = []
let newastronaut
let astrocount = 0
let asteroidcount = 0
let shipcount = 0
let objects = []
let rotation = 0
function setup() {
  rectMode(CENTER)
  createCanvas(windowWidth, windowHeight);
}

function keyPressed() {
  if (keyCode == 49) {
    let newastronaut = new Astronaut(random(windowWidth), random(windowHeight), random(-3, 3), random(-3, 3), 0)
    if (astrocount <= 10) {
      astronauts.push(newastronaut)
      astrocount++
    }
  }
  if (keyCode == 50) {
    let newasteroid = new Asteroid(random(windowWidth), random(windowHeight), random(-3, 3), random(-3, 3), 0)
    if (asteroidcount <= 7) {
      asteroids.push(newasteroid)
      asteroidcount++
    }
  }
  if (keyCode == 51) {
    let newspaceship = new Spaceship(random(windowWidth), random(windowHeight), random(-3, 3), random(-3, 3), 0)
    if (shipcount <= 3) {
      ships.push(newspaceship)
      shipcount++
    }
  }

}
function draw() {
  background(0);
  for (i = 0; i < astronauts.length; i++) {
    astronauts[i].draw()
    for (u = 0; u < asteroids.length; u++) {
      asteroids[u].draw()
      let d = dist(astronauts[i].astronautx, astronauts[i].astronauty, asteroids[u].asteroidx, asteroids[u].asteroidy)
      if (d < 30) {
        astronauts[i].velx *= -1
        astronauts[i].vely *= -1
      }
    }
    for (v = 0; v < ships.length; v++) {
      ships[v].draw()
      let shipastrod = dist(astronauts[i].astronautx, astronauts[i].astronauty, ships[v].x, ships[v].y)
      if (shipastrod < 40) {
        astronauts.splice(i, 1)
        break
      }
    }
  }
  for (i = 0; i < astronauts.length; i++) {
    astronauts[i].move()
  }
  for (u = 0; u < asteroids.length; u++) {
    asteroids[u].move()
  }
  for (u = 0; u < ships.length; u++) {
    ships[u].move()
  }

}