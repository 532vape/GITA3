class Spaceship {
  constructor(x, y, velx, vely) {
    this.x = x
    this.y = y
    this.velx = velx
    this.vely = vely
  }
  draw() {
    fill("lightblue")
    ellipse(this.x, this.y, 70, 40)
    fill("grey")
    ellipse(this.x, this.y+10, 100, 30)
  }
  move(){
    this.x+=this.velx
    this.y+=this.vely
    if (this.x -35 <= 0 ){
      this.x = windowWidth - 35
    }
    if (this.x + 35 >= windowWidth){
      this.x = 35
    }
    if (this.y - 10 <= 0){
      this.y = windowHeight - 30
    }
    if (this.y + 25 >= windowHeight){
      this.y = 20
    }
  }
}