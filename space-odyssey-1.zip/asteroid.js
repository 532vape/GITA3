class Asteroid {
  constructor(asteroidx, asteroidy, velx, vely) {
    this.asteroidx = asteroidx
    this.asteroidy = asteroidy
    this.velx = velx
    this.vely = vely
  }
  draw() {
    fill("grey")
    ellipse(this.asteroidx, this.asteroidy, 50, 50)
  }
  move() {
    this.asteroidx += this.velx
    this.asteroidy += this.vely
    if (this.asteroidx > windowWidth){
      this.asteroidx = 0
    }
    if (this.asteroidx < 0) {
      this.asteroidx = windowWidth
    }
    if (this.asteroidy > windowHeight) {
      this.asteroidy = 0
    }
    if (this.asteroidy < 0) {
      this.asteroidy = windowHeight
    }
  }
}