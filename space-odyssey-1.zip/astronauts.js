class Astronaut{
  constructor(astronautx,astronauty,velx,vely,angle){
    this.astronautx = astronautx
    this.astronauty = astronauty
    this.velx = velx
    this.vely = vely
    this.angle = angle
  }
  draw(){ //FIXXXXX
    fill(250)
    this.angle++
    angleMode(DEGREES)
    translate(this.astronautx,this.astronauty)
    rotate(this.angle)
    rect(0,0,40,44)
    ellipse(0,0,30,50)
    ellipse(0,-35,25,25)
    fill('gold')
    ellipse(0,-35,20,20)
    rotate(-this.angle)
    translate(-this.astronautx,-this.astronauty)
  }
  move(){
    this.astronautx += this.velx
    this.astronauty += this.vely
    if (this.astronautx > windowWidth){
      this.astronautx = 0
    }
    if (this.astronautx < 0){
      this.astronautx = windowWidth
    }
    if (this.astronauty > windowHeight){
      this.astronauty = 0
    }
    if (this.astronauty < 0){
      this.astronauty = windowHeight
    }
  }
}