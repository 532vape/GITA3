var x = 100
var y = 100
var leftright = 0
var updown = 0
let fishes = []
var sub
var r = 255
var g = 255
var b = 0

function setup() {
  createCanvas(windowWidth, windowHeight);
  for (let i = 0; i<20; i++){
    fishes[i] = new Fish(random(windowWidth),random(140,windowHeight),3,0)
  }
  sub = new Sub(100,100,3,1)
}

function draw() {
  background('blue');
  sub.display()
  sub.movesub()
  for (let i = 0; i<20; i++){ //fish dodge sub
    fishes[i].move()
    fishes[i].display()
    if (fishes[i].x+20>sub.x-50 && (fishes[i].y > sub.y - 50 && fishes[i].y < sub.y+50)){
        fishes[i].y -= 2;
        }
    else if(fishes[i].x+20>sub.x-50 && (fishes[i].y > sub.y - 40 && fishes[i].y < sub.y+110 && fishes[i].y > sub.y+50)){
      fishes[i].y += 2
    }
  }
  
}
