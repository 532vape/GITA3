class Sub{
  constructor(x,y,xspeed,yspeed){
    this.x = x
    this.y = y
    this.xspeed = xspeed
    this.yspeed = yspeed
    this.leftright = leftright
  }
  display(){
    fill(240)
    //rect(this.x-50,this.y-40, 320,100)//boundaries for fish dodging sub
    fill("black")
    rect(this.x,this.y,200,40)
    if (leftright == 0){
      fill(11, 252, 3)
      beginShape()
  vertex(this.x+35,this.y)
  vertex(this.x+120,this.y)
  vertex(this.x+100,this.y-20)
  vertex(this.x+40,this.y-20)
      vertex(this.x+30,this.y)
  endShape()
  arc(this.x,this.y+20, 80, 40, PI/2, (3*PI)/2);
  
  beginShape()
  vertex(this.x+200,this.y)
  vertex(this.x+245,this.y+12)
  vertex(this.x+245,this.y+28)
  vertex(this.x+200,this.y+40)
  endShape()
  
  beginShape()
  vertex(this.x+243,this.y+12)
  vertex(this.x+243,this.y-10)
  vertex(this.x+230,this.y-10)
  vertex(this.x+225,this.y+9)
  endShape()
  
  beginShape()
  vertex(this.x+243,this.y+28)
  vertex(this.x+243,this.y+45)
  vertex(this.x+230,this.y+45)
  vertex(this.x+224,this.y+34)
  endShape()
    }
      if (leftright == 1){
    beginShape()
  fill(11, 252, 3)
  vertex(this.x+165,this.y)
  vertex(this.x+75,this.y)
  vertex(this.x+95,this.y-20)
  vertex(this.x+155,this.y-20)
  endShape()
  
  arc(this.x+200, this.y+20, 80, 40, (3*PI)/2, PI/2);
  
  beginShape()
  vertex(this.x,this.y)
  vertex(this.x-45,this.y+12)
  vertex(this.x-45,this.y+28)
  vertex(this.x,this.y+40)
  endShape()
  
  beginShape()
  vertex(this.x-43,this.y+12)
  vertex(this.x-43,this.y-10)
  vertex(this.x-30,this.y-10)
  vertex(this.x-25,this.y+9)
  endShape()
  
  beginShape()
  vertex(this.x-43,this.y+28)
  vertex(this.x-43,this.y+45)
  vertex(this.x-30,this.y+45)
  vertex(this.x-25,this.y+34)
  endShape()
  }
      if (keyIsDown(65)){
    leftright = 0 //left
  }
  else if (keyIsDown(68)){
    leftright = 1 //rightdd
  }
  
  }
  movesub(){
    if (this.y > 50){
      this.y-=1
    }
    if (keyIsDown(83)){
    this.y+=5
  }
  if (keyIsDown(68)){
    this.x+=2
  }
  if (keyIsDown(65)){
    this.x-=2
  }
  }
  
}