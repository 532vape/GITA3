class Fish{
  constructor(x,y,xspeed,yspeed,r,g,b){
    this.x = x
    this.y = y
    this.xspeed = xspeed
    this.yspeed = yspeed
    this.r = r
    this.g = g
    this.b = b
  }
  move(){
    this.x+=this.xspeed
    this.y+=this.yspeed
  }
  display(){
    fill(this.r,this.g,this.b)
    ellipse(this.x,this.y,20,10)
    triangle(this.x-15,this.y-10,this.x-10,this.y,this.x-15,this.y+10)
    if (this.x>windowWidth){
      this.x = 0
      this.y = random(100,400)
      this.r = random(255)
      this.g = random(255)
      this.b = random(255)
    }
  }
}