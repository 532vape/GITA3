////https://www.geeksforgeeks.org/html5-game-development-infinitely-scrolling-background/
//https://thecodingtrain.com/CodingChallenges/111-animated-sprite.html
//https://gamedev.stackexchange.com/questions/92181/how-can-i-create-json-sprite-sheet-data-from-a-regular-sprite-sheet
//http://renderhjs.net/shoebox/
//https://www.youtube.com/watch?v=l0HoJHc-63Q
var backgroundimage
var backgroundx = 0
var bgendx = 0
var backgroundscrollspeed = 1

let runsheet;
let rundata;
let runanimation = [];

let heartsheet
let heartdata
let heartanimation = []

let laserx = 200
let lasery = 300
let lasers = []

let ufosheet
let ufodata
let ufoanimation = []

let bombsheet
let bombdata
let bombanimation = []
let bombs = []

let lasersheet
let laserdata
let laseranimation = []

let astronauty = 335
let astronautx = 330
let initialvel = -15
let accel = .7
let jumpstat = false

function preload() {
  rundata = loadJSON('astronautrun/astronautrun.json')
  runsheet = loadImage('astronautrun/astronautrun.png')
  heartdata = loadJSON('hearts/lives.json')
  heartsheet = loadImage('hearts/lives.png')
  ufodata = loadJSON('ufo/ufo.json')
  ufosheet = loadImage("ufo/ufo.png")
  bombdata = loadJSON('bomb/bomb.json')
  bombsheet = loadImage("bomb/bomb.png")
  laserdata = loadJSON('laser/laser.json')
  lasersheet = loadImage("laser/laser.png")
}

function setup() {
  //setup sprites and frame info
  createCanvas(800, 460);
  backgroundimage = loadImage('spacebg.png')
  let frames = rundata.frames
  for (i = 0; i < frames.length; i++) {
    let pos = frames[i].frame
    let img = runsheet.get(pos.x, pos.y, pos.w, pos.h)
    runanimation.push(img)
  }
  let frames2 = heartdata.frames
  for (i = 0; i < frames2.length; i++) {
    let pos = frames2[i].frame
    let img = heartsheet.get(pos.x, pos.y, pos.w, pos.h)
    heartanimation.push(img)
  }
  let ufoframes = ufodata.frames
  for (i = 0; i < ufoframes.length; i++) {
    let pos = ufoframes[i].frame
    let img = ufosheet.get(pos.x, pos.y, pos.w, pos.h)
    ufoanimation.push(img)
  }
  let bombframes = bombdata.frames
  for (i = 0; i < bombframes.length; i++) {
    let pos = bombframes[i].frame
    let img = bombsheet.get(pos.x, pos.y, pos.w, pos.h)
    bombanimation.push(img)
  }
  let laserframes = bombdata.frames
  for (i = 0; i < laserframes.length; i++) {
    let pos = laserframes[i].frame
    let img = lasersheet.get(pos.x, pos.y, pos.w, pos.h)
    laseranimation.push(img)
  }

  // for (let i = 0; i < 10; i++) {
  //   bombs[i] = new Bomb(100, 100, 1, 0)
  // }
}
let enemyx = 600
let enemyy = 250
let bombx = 100
let bomby = 100
let moveenemy = -1
let dropbomb = false
let timer = 0
let lives = 0
let score = 0
function mouseClicked() {
  lasers.push(new Laser(astronautx - 10, astronauty-100))
}
function draw() {
  timer += 1
  //infinite background scroll
  background(220);
  frameRate(30)
  image(backgroundimage, backgroundx, 0, 800, 460)
  image(backgroundimage, backgroundx + 800, 0, 800, 460)
  backgroundx -= backgroundscrollspeed

  //draw sprites
  stroke('red')
  image(runanimation[frameCount % runanimation.length], astronautx, astronauty)
  noFill()
  //hitbox visualization

  //create health bar that changes based on hits
  image(heartanimation[lives], 670, 10)
  text("Points: " + score,700,100,100,100)
  if (enemyy > 250) {
    moveenemy *= -1
  }
  for (i = 0; i < bombs.length; i++) {
    let bombdist = dist(astronautx + 50, astronauty + 50, bombs[i].x + 89, bombs[i].y + 89.5)
    bombs[i].draw()
    bombs[i].move()
    if (bombdist <= 50) {
      bombs.splice(i, 1)
      lives += 1
      console.log(lives)
      break;
    }
  }
  for (i = 0; i < lasers.length; i++) {
    let enemydist = dist(lasers[i].x+145,lasers[i].y+150,enemyx+100,enemyy+100)
    lasers[i].draw()
    lasers[i].move() 
    if (enemydist<=70){
      score+=10
      console.log(score)
      lasers.splice(i,1)
      break;
    }
  }
  if (lives >= 6) {
    window.location.reload();
  }

  if (timer % 164 == 0) {
    bombs.push(new Bomb(600, 320, 1, 0))
  }

  if (enemyy < 170) {
    moveenemy *= -1
  }

  enemyy += moveenemy
  //enemy ufo
  image(ufoanimation[frameCount % ufoanimation.length], enemyx, enemyy)
  //bomb

  if (backgroundx == -800) {
    backgroundx = 0
  }
  if (jumpstat == true) {
    if (astronauty >= 340) {
      jumpstat = false
      initialvel = -15
    }
    initialvel += accel
    astronauty += initialvel
  }
  //create health bar that changes based on how many lives you have

  //create a rolling bomb that explodes after a certain amount of time or if it touches astronaut
  //for () create a loop that periodically spawns a bomb
}

function keyPressed() {
  if (keyCode == 32 && jumpstat == false) {
    //console.log("jump")
    //astronauty -= initialvel
    jumpstat = true
  }
}