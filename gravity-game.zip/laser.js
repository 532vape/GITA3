class Laser {
  constructor(x,y){
    this.x = x
    this.y = y
  }
  draw(){
    image(laseranimation[0], this.x, this.y)
  }
  move(){
    this.x += 20
  }
}