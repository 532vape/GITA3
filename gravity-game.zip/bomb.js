class Bomb{
  constructor(x,y,velx,vely){
    this.x = x
    this.y = y
    this.velx = velx
    this.vely = vely
  }
  draw(){
    image(bombanimation[frameCount % bombanimation.length], this.x, this.y)
  }
  move(){
    this.x -= 5
  }
}