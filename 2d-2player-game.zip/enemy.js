class Enemy{
  constructor(x,y,xvel,yvel,health,dead,color){
  this.x = x
  this.y = y
    this.xvel = xvel
    this.yvel = yvel
    this.health = health
    this.dead = dead
    this.color = color
  }
  display(){
    fill(this.color)
  circle(this.x,this.y,20)
  }
  move(){
    if(this.x == 175 && this.y <=225){
      this.y+=this.yvel
    }
    if(this.y == 225 && this.x <=425){
      this.x+=this.xvel
    }
    if (this.x == 425 && this.y <=425){
      this.y += this.yvel
    }
    if (this.y == 425 && this.x >=125){
      this.x -= this.xvel
    }
    if (this.x == 125 && this.y >= 425){
      this.y += this.yvel
    }
  }
}