class Turret{
  constructor(x,y,angle,targetx,targety,turretdist,lockon){
    this.x = x
    this.y = y
    this.angle = angle
    this.targetx = targetx
    this.targety = targety
    this.turretdist=turretdist
    this.lockon=lockon
  }
  display(){
    imageMode(CENTER)
    this.angle = Math.atan2(this.targety-(this.y +25),this.targetx-(this.x +25))
    translate((this.x + 25),(this.y + 25))
    rotate(this.angle)
    image(turret,0,0,50,50)
    rotate(-this.angle)
    translate(-(this.x+25),-(this.y+25))
  }
  
  }

