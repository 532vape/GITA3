class Units {
  constructor(x,y,color,selected)
  {
    this.x = x
    this.y = y
    this.color = color
    this.selected = selected
  }
  display(){
    fill(this.color)
    rect(this.x,this.y,100,100)
  }
}