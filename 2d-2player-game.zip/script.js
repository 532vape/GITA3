var tiles = [];
var units = []
var enemyselect = []
let turret
let turretdata
let turretanimation = []
let turrets = []
let enemies = []
let money = 100
let firerate = 0
let enemy1
let enemy2
let enemy3
let health = 5
function preload() {
  turret = loadImage('turret/turret1.png')
  // turret2 = loadImage('turret/turret1.png')
  enemy1 = loadImage('enemies/enemy1.png')
  enemy2 = loadImage('enemies/enemy2.png')
  enemy3 = loadImage('enemies/enemy3.png')
  for (var x = 0; x < 12; x++) {
    tiles[x] = []
    units[x] = []
    enemyselect[x] = []
    for (var y = 0; y < 12; y++) {
      tiles[x][y] = new Tile((x * 50), y * 50, 'white',false);
      units[x] = new Units((x*100),700,"white",false)
      enemyselect[x][y] = new Enemyselect(700,(y*100),'white',false)
    }
  }
  // for (var i =0; i<enemies.length;i++){
  // enemies[i] = new Enemy(175,0,1,1,4,false,'white')
  // }
  // for (var x=0;x<)
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);
}

function draw() {
  background(220)
  strokeWeight(1)
  angleMode(RADIANS)
  for (var x = 0; x < 12; x++) {
    tiles[x][y] = []
    for (var y = 0; y < 12; y++) {
      tiles[x][y].display(); //create the tilegrid for the game
    }
  }
  fill("red") //draw tower selection area
  textSize(20)
text("Credits: "+money,0,650)
  text('Player 1 place towers and defend while Player 2 send enemies to try and destroy Player 1s base',200,650)
  for (var x=0;x<1;x++){
        units[x].display()
  }
  for (var x=0;x<1;x++){
    enemyselect[x][y] = []
    for (var y=0;y<3;y++){
    enemyselect[x][y].display()
      imageMode(CORNER)
      image(enemy1,enemyselect[0][0].x,enemyselect[0][0].y)
      image(enemy2,enemyselect[0][1].x,enemyselect[0][1].y)
      image(enemy3,enemyselect[0][2].x,enemyselect[0][2].y)
    }
  }
          drawpath()
  for(var u =0;u<turrets.length;u++){
    turrets[u].display()
    for (var i = 0; i<enemies.length;i++){
       enemies[i].display()
      if (enemies[i].y > 600){
        health -=1
        enemies.splice(i,1)
        console.log(health)
      }
      if (health <=0){
        location.reload()
      }
      turrets[u].turretdist = dist(enemies[i].x,enemies[i].y,turrets[u].x,turrets[u].y) //distance between turret and the enemy
      if (turrets[u].turretdist < 200 ){ //if the distance between enemy and turret is <100 pixels
         //if target is chosen record the values so that the turret can appear to track the enemy
        turrets[u].targetx = enemies[i].x
        turrets[u].targety = enemies[i].y
        firerate+=1
        if (firerate % 2 == 0){
        enemies[i].health -= 1
        }
        if (enemies[i].health<=0){
          enemies.splice(i,1)
          money+=10
        }
      }
      }
    }
  for (var i=0;i<enemies.length;i++){
     enemies[i].move()
  }
}

  
    
  
 


function mouseClicked(){
  for (var x = 0; x < 12; x++) {
      for (var y = 0; y < 12; y++) {
        if (((mouseX <= tiles[x][y].x + 50 && mouseX >= tiles[x][y].x) && (mouseY <= tiles[x][y].y + 50 && mouseY >= tiles[x][y].y))) {
          if (units[0].selected == true && tiles[x][y].path == false && money >= 50){
          tiles[x][y].color = "red"
          turrets.push(new Turret(tiles[x][y].x, tiles[x][y].y,0,0,0,0,false))
            money-=50
          }
          // else if (units[1].selected == true){
          //   tiles[x][y].color = "green"
          //   turrets.push(new Turret(tiles[x][y].x, tiles[x][y].y,0,0,0,0,false))
          // }
          // else if (units[2].selected == true){
          //   tiles[x][y].color = "orange"
          //   turrets.push(new Turret(tiles[x][y].x, tiles[x][y].y,0,0,0,0,false))
          // }
        }
      }
    }
  for (var x = 0; x < 3; x ++){
      if (((mouseX <= units[x].x + 100 && mouseX >= units[x].x) && (mouseY <=               units[x].y + 100 && mouseY >= units[x].y))) {
        if (units[x].selected == false){
          units[x].color = "red"
          units[x].selected = true
        }
        else {
          units[x].color = "white"
          units[x].selected = false
        }

  }
    if (units[0].selected == true){
      units[0].color = "red"
      // units[1].color = "white"
      // units[2].color = "white"
    }
    // if (units[1].selected == true){
    //   units[0].color = "white"
    //   units[1].color = "green"
    //   units[2].color = "white"
    // }
    // if (units[2].selected == true){
    //   units[0].color = "white"
    //   units[1].color = "white"
    //   units[2].color = "orange"
    // }
    
    
}
  for (var x=0;x<1;x++){
    for (var y=0;y<3;y++){
      if (((mouseX <= enemyselect[0][0].x + 100 && mouseX >= enemyselect[0][0].x) && (mouseY <= enemyselect[0][0].y + 100 && mouseY >= enemyselect[0][0].y))) {
        enemies.push(new Enemy(175,0,1,1,100,false,'white'))
      }
      if (((mouseX <= enemyselect[0][1].x + 100 && mouseX >= enemyselect[0][1].x) && (mouseY <= enemyselect[0][1].y + 100 && mouseY >= enemyselect[0][1].y))) {
        enemies.push(new Enemy(175,0,1,1,200,false,'blue'))
      }
      if (((mouseX <= enemyselect[0][2].x + 100 && mouseX >= enemyselect[0][2].x) && (mouseY <= enemyselect[0][2].y + 100 && mouseY >= enemyselect[0][2].y))) {
        enemies.push(new Enemy(175,0,1,1,400,false,'red'))
      }
      // if (enemyselect[0].selected == true){
      //   enemyselect[0].color = 'red'
      //   enemyselect[1].color = 'white'
      //   enemyselect[2].color = 'white'
      // }
      // if (enemyselect[1].selected == true){
      //   enemyselect[0].color = 'white'
      //   enemyselect[1].color = 'red'
      //   enemyselect[2].color = 'white'
      // }
      // if (enemyselect[2].selected == true){
      //   enemyselect[0].color = 'white'
      //   enemyselect[1].color = 'white'
      //   enemyselect[2].color = 'red'
      // }
    }
  }
}
function drawpath(){
  //draw path for the enemies to follow
  for (var x=0;x<12;x++){
    for (var y=0;y<12;y++){
      if (tiles[x][y].y <= 150 && tiles[x][y].x == 150){
        tiles[x][y].color = "green"
        tiles[x][y].path = true
      }
      if (tiles[x][y].y == 200 && tiles[x][y].x >= 150 && tiles[x][y].x <=400){
        tiles[x][y].color = "green"
        tiles[x][y].path = true
      }
      if (tiles[x][y].y>200 &&tiles[x][y].y <=400 && tiles[x][y].x == 400){
        tiles[x][y].color = "green"
        tiles[x][y].path = true
      }
      if (tiles[x][y].y== 400 && tiles[x][y].x < 400 && tiles[x][y].x >= 100){
        tiles[x][y].color = "green"
        tiles[x][y].path = true
      }
      if (tiles[x][y].y >= 400 && tiles[x][y].x == 100){
        tiles[x][y].color = "green"
        tiles[x][y].path = true
        if (tiles[x][y].y == 550){
          tiles[x][y].color = 'blue'
        }
      }
    }
  }
}

